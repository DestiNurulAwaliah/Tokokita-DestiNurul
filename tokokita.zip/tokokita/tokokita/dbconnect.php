<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","tokokita");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>